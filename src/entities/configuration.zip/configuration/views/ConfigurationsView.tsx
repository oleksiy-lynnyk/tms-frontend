// src/entities/configuration/views/ConfigurationsView.tsx
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import GenericEntityTable, { ColumnDefinition } from '@/components/common/GenericEntityTable';
import type { ConfigurationDTO } from '@/entities/configuration';
import {
    fetchConfigurations,
    createConfiguration,
    updateConfiguration,
    deleteConfiguration,
} from '@/entities/configuration';
import ConfigurationModal from '@/entities/configuration/components/ConfigurationModal';

const columns: ColumnDefinition<ConfigurationDTO>[] = [
    { key: 'name', label: 'Name', sortable: true },
    { key: 'os', label: 'OS' },
    { key: 'browser', label: 'Browser' },
    { key: 'device', label: 'Device' },
    { key: 'description', label: 'Description' },
];

const PAGE_SIZE_OPTIONS = [10, 20, 50];

const ConfigurationsView: React.FC = () => {
    const { projectId } = useParams<{ projectId: string }>();
    const [configs, setConfigs] = useState<ConfigurationDTO[]>([]);
    const [form, setForm] = useState<Partial<ConfigurationDTO>>({});
    const [editConfig, setEditConfig] = useState<ConfigurationDTO | undefined>(undefined);
    const [showModal, setShowModal] = useState(false);
    const [isSaving, setIsSaving] = useState(false);

    const [page, setPage] = useState(0);
    const [pageSize, setPageSize] = useState(PAGE_SIZE_OPTIONS[0]);

    const total = configs.length;
    const totalPages = Math.ceil(total / pageSize);
    const paged = configs.slice(page * pageSize, (page + 1) * pageSize);

    const fetchAll = async () => {
        if (!projectId) return;
        const list = await fetchConfigurations(projectId);
        setConfigs(list);
    };

    useEffect(() => {
        fetchAll();
    }, [projectId]);

    const handleEdit = (item?: ConfigurationDTO) => {
        setEditConfig(item);
        setForm(item ?? {});
        setShowModal(true);
    };

    const handleSave = async () => {
        if (!projectId) return;
        setIsSaving(true);
        if (form.id) {
            await updateConfiguration(form.id, form as ConfigurationDTO);
        } else {
            await createConfiguration({ ...(form as Omit<ConfigurationDTO, 'id'>), projectId });
        }
        setIsSaving(false);
        setShowModal(false);
        setForm({});
        await fetchAll();
    };

    const handleDelete = async (id: string) => {
        if (!projectId) return;
        await deleteConfiguration(id);
        await fetchAll();
    };

    return (
        <div className="content-container">
            <div className="testcase-toolbar mb-3">
                <button
                    className="bs-btn bs-btn-primary"
                    onClick={() => handleEdit(undefined)}
                >
                    + New Configuration
                </button>
            </div>

            <GenericEntityTable<ConfigurationDTO>
                items={paged}
                columns={columns}
                onEdit={handleEdit}
                onDelete={handleDelete}
                page={page}
                pageSize={pageSize}
                total={total}
                totalPages={totalPages}
                onPageChange={setPage}
            />

            <ConfigurationModal
                show={showModal}
                config={editConfig}
                onClose={() => setShowModal(false)}
                onSave={handleSave}
                form={form}
                setForm={setForm}
                isSaving={isSaving}
            />
        </div>
    );
};

export default ConfigurationsView;
