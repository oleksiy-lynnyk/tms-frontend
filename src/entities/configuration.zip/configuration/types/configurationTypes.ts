// src/entities/configuration/types/configurationTypes.ts

/** DTO із бекенду */
export interface ConfigurationDTO {
    /** Унікальний ідентифікатор */
    id: string;
    /** Ідентифікатор проєкту */
    projectId: string;
    /** Назва конфігурації */
    name: string;
    /** Операційна система */
    os?: string;
    /** Браузер */
    browser?: string;
    /** Пристрій */
    device?: string;
    /** Опис */
    description?: string;
}

/** Для створення нової конфігурації (без `id`) */
export type CreateConfigurationDTO = Omit<ConfigurationDTO, 'id'>;

/** Для часткового оновлення */
export type UpdateConfigurationDTO = Partial<Omit<ConfigurationDTO, 'id'>>;
