// src/entities/configuration/index.ts

// 1) Типи
export * from './types/configurationTypes';

// 2) API-клієнт
export * from './api/configurationApi';

// 3) UI-компоненти
export { default as ConfigurationModal } from './components/ConfigurationModal';

// 4) View
export { default as ConfigurationsView } from './views/ConfigurationsView';
