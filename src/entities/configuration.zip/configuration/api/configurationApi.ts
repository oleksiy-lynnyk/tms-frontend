// src/entities/configuration/api/configurationApi.ts
import { api } from '@/api/axios';
import type {
    ConfigurationDTO,
    CreateConfigurationDTO,
    UpdateConfigurationDTO,
} from '@/entities/configuration/types/configurationTypes';

/**
 * Отримати всі конфігурації для проекту
 */
export const fetchConfigurations = async (
    projectId: string
): Promise<ConfigurationDTO[]> => {
    const { data } = await api.get<ConfigurationDTO[]>(
        `/configurations/project/${projectId}`
    );
    return data;
};

/**
 * Створити конфігурацію
 */
export const createConfiguration = async (
    config: CreateConfigurationDTO
): Promise<ConfigurationDTO> => {
    const { data } = await api.post<ConfigurationDTO>(
        '/configurations',
        config
    );
    return data;
};

/**
 * Оновити конфігурацію
 */
export const updateConfiguration = async (
    id: string,
    config: UpdateConfigurationDTO
): Promise<ConfigurationDTO> => {
    const { data } = await api.put<ConfigurationDTO>(
        `/configurations/${id}`,
        config
    );
    return data;
};

/**
 * Видалити конфігурацію
 */
export const deleteConfiguration = async (id: string): Promise<void> => {
    await api.delete(`/configurations/${id}`);
};
